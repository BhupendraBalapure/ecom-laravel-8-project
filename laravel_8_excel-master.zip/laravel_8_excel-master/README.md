# laravel_8_crud
This is a laravel 8 CRUD app
