<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Http\Controllers\Controller;


class Image extends Model
{
    use HasFactory;
    protected $table ='images';

    protected $fillable = ['file'];
}
