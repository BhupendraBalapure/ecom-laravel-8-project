<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="media mb-4">
        
        <img src="<?php echo e(Storage::disk('local')->url('files/'.$item->product_image)); ?>" alt="image here" class="d-flex align-self-start rounded mr-3" height="64">
        
        <div class="media-body">
            <h5 class="mt-0 font-16"><?php echo e($item->product_name); ?></h5>
            <div class="btn-group">
                <button class="btn btn-sm btn-primary">Edit</button>
                <button class="btn btn-sm btn-danger">Delete</button>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <code>No product found</code>
<?php endif; ?><?php /**PATH /home/kiran/Desktop/Laravel-8-Ajax-CRUD-with-Image-Upload-master(1)/Laravel-8-Ajax-CRUD-with-Image-Upload-master/resources/views/all_products.blade.php ENDPATH**/ ?>